TODO

fix bug where Filter by distance returns all tweets (not for just candidate selected)
